let palabrasAdivinar = [
    "Abanico", "Almuerzo", "Amistad", "Arquitecto", "Automóvil",
	"Bicicleta", "Biblioteca", "Bolígrafo", "Brillante", "Buscador",
    "Caballero", "Calcetín", "Calendario", "Caramelo", "Castillo",
	"Delicado", "Deporte", "Descansar", "Desierto", "Diccionario",
	"Edificio", "Elefante", "Escalera", "Escritorio", "Estudiante",
	"Fachada", "Factura", "Fantasía", "Farmacia", "Florero",
	"Galaxia", "Gasolina", "Generoso", "Gigante", "Guitarra",
	"Hablaría", "Helado", "Hermoso", "Historia", "Hospital",
	"Idioma", "Iglesia", "Imagen", "Increíble", "Invierno",
	"Jardín", "Jofaina", "Jornada", "Juguete", "Justicia",
	"Lámpara", "Lectura", "Libertad", "Limpieza", "Lucero",
	"Maestro", "Maleta", "Mariposa", "Martillo", "Mercurio",
    "Naranja", "Natación", "Neblina", "Negocio", "Nocturno",
	"Objetivo", "Obligar", "Obstáculo", "Orquesta", "Oxígeno",
	"Palabra", "Pantalla", "Película", "Perfume", "Próximo",
	"Querido", "Químico", "Quitaría", "Quinto", "Quietud",
	"Radiante", "Recuerdo", "Refresco", "Relojero", "Riqueza",
	"Saludar", "Semilla", "Silencio", "Símbolo", "Sombrero",
	"Teclado", "Teléfono", "Terminar", "Trabajo", "Turista",
	"Universo", "Urgente", "Usuario", "Utilidad", "Utopía"
]

const indiceAleatorio = 
const palabraSeleccionada = palabrasAdivinar[indiceAleatorio];

let username = "";

const readline = require('readline');

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});


username = await getUserInput("What is your name?"); 


function getUserInput(question) {
    return new Promise((resolve) => {
        rl.question(question + " ", (answer) => {
            resolve(answer);
        });
    });
}


startGame();

async function startGame(){
    console.log("Bienvenido al jueho del Ahorcado")
    console.log("si deseas terminar el juego ingrese: 33728905")

    while (resp !="33728905")
        long = palalabra.length


    return rl.close();
}